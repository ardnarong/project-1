<?php
echo 'welcome '.ucfirst($udata->name); 
?>
<a href="<?php echo base_url(); ?>index.php/users/logout">logout</a>